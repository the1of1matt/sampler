function applyState(state) {
  document.getElementById('status').textContent =
    state.status === 'connected' ? '🟢 Connected' : '🔴 Disconnected';
  document.getElementById('device').textContent = state.connectedDeviceName || '—';
  document.getElementById('connType').textContent = state.connectionType || '—';
  document.getElementById('macIP').textContent = state.macIP || '—';
  document.getElementById('port').textContent = state.port;
  document.getElementById('virtualMidi').textContent =
    `MG Controller MIDI ${state.virtualMidiActive ? 'Active' : 'Inactive'}`;
  document.getElementById('lastMessage').textContent = state.lastMessage || '—';

  const qr = document.getElementById('qr');
  if (state.qrDataUrl) qr.src = state.qrDataUrl;
}

window.bridgeAPI.onStatus((state) => applyState(state));
window.bridgeAPI.onMessage((text) => {
  document.getElementById('lastMessage').textContent = text;
});

window.bridgeAPI.getState().then(applyState);
