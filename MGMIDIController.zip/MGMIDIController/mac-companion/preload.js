//
// preload.js — runs in an isolated context with access to Node/Electron
// APIs, exposing only a minimal safe surface to the renderer (which itself
// has nodeIntegration disabled).
//

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('bridgeAPI', {
  getState: () => ipcRenderer.invoke('bridge:getState'),
  onStatus: (callback) => {
    ipcRenderer.on('bridge:status', (_event, state) => callback(state));
  },
  onMessage: (callback) => {
    ipcRenderer.on('bridge:message', (_event, text) => callback(text));
  }
});
