//
// midiBridge.js
//
// Owns the whole bridge: the CoreMIDI virtual output ("MG Controller MIDI"),
// the WebSocket server the iPad connects to, and Bonjour advertising for
// future zero-config discovery. Emits state changes so the renderer window
// can display them.
//

const os = require('os');
const midi = require('@julusian/midi');
const WebSocket = require('ws');
const QRCode = require('qrcode');
const { Bonjour } = require('bonjour-service');

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function noteName(n) {
  const name = NOTE_NAMES[((n % 12) + 12) % 12];
  const octave = Math.floor(n / 12) - 1;
  return `${name}${octave}`;
}

function localIPv4() {
  const ifaces = os.networkInterfaces();
  // Prefer en0 (typical macOS Wi-Fi interface name) if present.
  const preferredOrder = Object.keys(ifaces).sort((a, b) => (a === 'en0' ? -1 : b === 'en0' ? 1 : 0));
  for (const name of preferredOrder) {
    for (const iface of ifaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return null;
}

class MIDIBridge {
  constructor({ port, virtualPortName, onStatus, onMessage }) {
    this.port = port;
    this.virtualPortName = virtualPortName;
    this.onStatus = onStatus || (() => {});
    this.onMessage = onMessage || (() => {});

    this.output = null;
    this.wss = null;
    this.bonjourInstance = null;
    this.bonjourService = null;
    this.refreshTimer = null;

    /** @type {Map<WebSocket, {name: string, ip: string, connectedAt: number}>} */
    this.clients = new Map();

    this.state = {
      status: 'disconnected',
      connectedDeviceName: '—',
      connectionType: '—',
      macIP: localIPv4() || 'Unavailable',
      port: this.port,
      virtualMidiActive: false,
      lastMessage: '—',
      qrDataUrl: null
    };
  }

  getState() {
    return this.state;
  }

  start() {
    this._createVirtualPort();
    this._startWebSocketServer();
    this._advertiseBonjour();
    this._emitStatus();
    this.refreshTimer = setInterval(() => this._emitStatus(), 5000);
  }

  stop() {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    try { this.wss && this.wss.close(); } catch (e) { /* noop */ }
    try { this.output && this.output.closePort(); } catch (e) { /* noop */ }
    try {
      if (this.bonjourInstance) {
        this.bonjourInstance.unpublishAll(() => this.bonjourInstance.destroy());
      }
    } catch (e) { /* noop */ }
  }

  // --- Setup -----------------------------------------------------------

  _createVirtualPort() {
    try {
      this.output = new midi.Output();
      this.output.openVirtualPort(this.virtualPortName);
      this.state.virtualMidiActive = true;
      console.log(`[MGMIDIBridge] Virtual MIDI port "${this.virtualPortName}" created.`);
    } catch (err) {
      console.error('[MGMIDIBridge] Failed to create virtual MIDI port:', err);
      this.state.virtualMidiActive = false;
    }
  }

  _startWebSocketServer() {
    this.wss = new WebSocket.Server({ port: this.port });

    this.wss.on('connection', (socket, req) => {
      const ip = (req.socket.remoteAddress || 'unknown').replace('::ffff:', '');
      const client = { name: 'iPad Controller', ip, connectedAt: Date.now() };
      this.clients.set(socket, client);
      console.log(`[MGMIDIBridge] Client connected from ${ip}`);
      this._updateConnectionState();

      socket.on('message', (raw) => {
        let msg;
        try {
          msg = JSON.parse(raw.toString());
        } catch (e) {
          return; // ignore malformed frames
        }
        this._handleMessage(msg, socket);
      });

      socket.on('close', () => {
        this.clients.delete(socket);
        console.log(`[MGMIDIBridge] Client disconnected: ${ip}`);
        this._updateConnectionState();
      });

      socket.on('error', (err) => {
        console.error('[MGMIDIBridge] Socket error:', err);
        this.clients.delete(socket);
        this._updateConnectionState();
      });
    });

    this.wss.on('error', (err) => {
      console.error('[MGMIDIBridge] WebSocket server error:', err);
    });

    console.log(`[MGMIDIBridge] WebSocket server listening on port ${this.port}`);
  }

  _advertiseBonjour() {
    try {
      this.bonjourInstance = new Bonjour();
      this.bonjourService = this.bonjourInstance.publish({
        name: 'MG MIDI Bridge',
        type: 'mgmidibridge',
        port: this.port,
        txt: { app: 'MG MIDI Controller' }
      });
      console.log('[MGMIDIBridge] Bonjour service advertised (_mgmidibridge._tcp).');
    } catch (err) {
      console.error('[MGMIDIBridge] Bonjour advertise failed:', err);
    }
  }

  // --- Connection / message handling -----------------------------------

  _updateConnectionState() {
    if (this.clients.size > 0) {
      const first = [...this.clients.values()][0];
      this.state.status = 'connected';
      this.state.connectedDeviceName = `${first.name} (${first.ip})`;
      this.state.connectionType = 'Wi-Fi';
    } else {
      this.state.status = 'disconnected';
      this.state.connectedDeviceName = '—';
      this.state.connectionType = '—';
    }
    this._emitStatus();
  }

  _handleMessage(msg, socket) {
    switch (msg.type) {
      case 'hello': {
        const client = this.clients.get(socket);
        if (client && typeof msg.name === 'string' && msg.name.trim()) {
          client.name = msg.name.trim();
        }
        this._updateConnectionState();
        break;
      }
      case 'noteOn':
        this._sendRaw(0x90, msg.channel, msg.note, msg.velocity ?? 100);
        this._describe(`Note ON  ${noteName(msg.note)}  Velocity ${msg.velocity ?? 100}  Ch${msg.channel || 1}`);
        break;
      case 'noteOff':
        this._sendRaw(0x80, msg.channel, msg.note, msg.velocity ?? 0);
        this._describe(`Note OFF ${noteName(msg.note)}  Ch${msg.channel || 1}`);
        break;
      case 'cc':
        this._sendRaw(0xB0, msg.channel, msg.controller, msg.value);
        this._describe(`CC ${msg.controller}  Value ${msg.value}  Ch${msg.channel || 1}`);
        break;
      case 'pitchBend': {
        const v = Math.max(0, Math.min(16383, msg.value ?? 8192));
        const lsb = v & 0x7f;
        const msb = (v >> 7) & 0x7f;
        this._sendRaw(0xe0, msg.channel, lsb, msb);
        this._describe(`Pitch Bend ${v}  Ch${msg.channel || 1}`);
        break;
      }
      default:
        break; // unknown message type — ignore rather than crash the bridge
    }
  }

  _sendRaw(statusBase, channel, data1, data2) {
    if (!this.output) return;
    const ch = Math.max(1, Math.min(16, channel || 1)) - 1;
    const status = statusBase | ch;
    this.output.sendMessage([status, (data1 ?? 0) & 0x7f, (data2 ?? 0) & 0x7f]);
  }

  _describe(text) {
    this.state.lastMessage = text;
    this.onMessage(text);
  }

  async _emitStatus() {
    this.state.macIP = localIPv4() || 'Unavailable';
    if (this.state.macIP !== 'Unavailable') {
      try {
        this.state.qrDataUrl = await QRCode.toDataURL(
          `ws://${this.state.macIP}:${this.port}`,
          { margin: 1, width: 180, color: { dark: '#dde2e8', light: '#00000000' } }
        );
      } catch (e) {
        // non-fatal — QR just won't render this cycle
      }
    }
    this.onStatus(this.state);
  }
}

module.exports = { MIDIBridge };
