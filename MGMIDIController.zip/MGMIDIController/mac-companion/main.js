//
// main.js — Electron main process.
//
// Creates the small status window + menu bar (Tray) icon, starts the
// MIDIBridge automatically on launch (no user action required), and relays
// bridge state to the renderer over IPC.
//

const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain } = require('electron');
const path = require('path');
const { MIDIBridge } = require('./src/midiBridge');

const BRIDGE_PORT = 5004;
const VIRTUAL_PORT_NAME = 'MG Controller MIDI';

let mainWindow = null;
let tray = null;
let bridge = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 380,
    height: 560,
    resizable: false,
    fullscreenable: false,
    title: 'MG MIDI Bridge',
    backgroundColor: '#0c0f12',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Menu-bar-app behavior: closing the window hides it instead of quitting,
  // so the bridge keeps running in the background.
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray() {
  const iconPath = path.join(__dirname, 'renderer', 'assets', 'trayTemplate.png');
  let icon = nativeImage.createFromPath(iconPath);
  if (icon.isEmpty()) {
    // Fallback so the app still runs even before a custom icon asset is added.
    icon = nativeImage.createEmpty();
  }
  icon.setTemplateImage(true);
  tray = new Tray(icon);
  tray.setToolTip('MG MIDI Bridge');
  updateTrayMenu('disconnected');

  tray.on('click', () => {
    if (!mainWindow) return;
    mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
  });
}

function updateTrayMenu(status) {
  if (!tray) return;
  const menu = Menu.buildFromTemplate([
    { label: status === 'connected' ? '🟢 Connected' : '🔴 Disconnected', enabled: false },
    { type: 'separator' },
    { label: 'Show Window', click: () => mainWindow && mainWindow.show() },
    { type: 'separator' },
    {
      label: 'Quit MG MIDI Bridge',
      click: () => {
        app.isQuitting = true;
        app.quit();
      }
    }
  ]);
  tray.setContextMenu(menu);
}

app.whenReady().then(() => {
  createWindow();
  createTray();

  bridge = new MIDIBridge({
    port: BRIDGE_PORT,
    virtualPortName: VIRTUAL_PORT_NAME,
    onStatus: (state) => {
      updateTrayMenu(state.status);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('bridge:status', state);
      }
    },
    onMessage: (text) => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('bridge:message', text);
      }
    }
  });

  bridge.start(); // starts automatically — no user action required

  ipcMain.handle('bridge:getState', () => bridge.getState());

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else mainWindow.show();
  });
});

app.on('window-all-closed', () => {
  // Stay running (menu-bar style) even with the window closed — do NOT quit.
});

app.on('before-quit', () => {
  app.isQuitting = true;
  if (bridge) bridge.stop();
});
